package pt.ulusofona.aed.rockindeisi2023;

public class QueryResult {
    String result;
    long time;
}
